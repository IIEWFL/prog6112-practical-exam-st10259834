/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package exam_q2;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MovieTicketSales class methods
 */
public class UnitTesting {

    public UnitTesting() {
    }

    // Test for calculating total ticket price successfully
    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 3, 150.0);
        double totalPrice = sales.calculateTotalTicketPrice();
        double expectedPrice = 150.0 * 3; // 3 tickets, each costing 150.0
        assertEquals(expectedPrice, totalPrice, "Total ticket price should be calculated correctly");
    }

    // Test for invalid negative ticket count
    @Test
    public void testInvalidNegativeTicketCount() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", -2, 150.0);
        assertThrows(IllegalArgumentException.class, () -> {
            sales.calculateTotalTicketPrice();
        }, "Negative ticket count should throw IllegalArgumentException");
    }

    // Test for invalid negative ticket price
    @Test
    public void testInvalidNegativeTicketPrice() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 3, -100.0);
        assertThrows(IllegalArgumentException.class, () -> {
            sales.calculateTotalTicketPrice();
        }, "Negative ticket price should throw IllegalArgumentException");
    }

    // Test for empty movie name
    @Test
    public void testEmptyMovieName() {
        MovieTicketSales sales = new MovieTicketSales("", 3, 150.0);
        assertThrows(IllegalArgumentException.class, () -> {
            sales.calculateTotalTicketPrice();
        }, "Empty movie name should throw IllegalArgumentException");
    }

    // Test for valid movie name
    @Test
    public void testValidMovieName() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 3, 150.0);
        assertDoesNotThrow(() -> {
            sales.calculateTotalTicketPrice();
        }, "Valid movie name 'Oppenheimer' should not throw an exception");
    }

    // Test for movie name that is too short
    @Test
    public void testMovieNameTooShort() {
        MovieTicketSales sales = new MovieTicketSales("Op", 3, 150.0);
        assertThrows(IllegalArgumentException.class, () -> {
            sales.calculateTotalTicketPrice();
        }, "Movie name 'Op' should throw IllegalArgumentException because it is too short");
    }

    // Test for calculating ticket price with VAT correctly
    @Test
    public void testValidTicketPriceWithVAT() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 2, 100.0);
        double totalPrice = sales.calculateTotalTicketPriceWithVAT();
        assertEquals(230.0, totalPrice, "Valid ticket price with VAT should be correctly calculated");
    }

    // Test for zero ticket count
    @Test
    public void testZeroTicketCount() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 0, 100.0);
        double totalPrice = sales.calculateTotalTicketPrice();
        assertEquals(0.0, totalPrice, "Zero ticket count should result in zero total price");
    }

    // Test for successful sales report generation
    @Test
    public void testGenerateSalesReport() {
        MovieTicketSales sales = new MovieTicketSales("Oppenheimer", 2, 100.0);
        String report = sales.generateSalesReport();
        String expectedReport = "Movie: Oppenheimer\nTickets Sold: 2\nTicket Price: 100.0\nTotal: 230.0";
        assertEquals(expectedReport, report, "Generated sales report should match the expected report format");
    }

    // Test for identifying the top-performing movie
    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        String[] movies = {"Oppenheimer", "Napoleon"};
        int[] totalSales = {6300, 6200};
        MovieTicketSales movieTickets = new MovieTicketSales("", new int[0]); // Placeholder instance

        String topMovie = movieTickets.TopMovie(movies, totalSales);

        assertEquals("Oppenheimer", topMovie, "The top-performing movie should be Oppenheimer");
    }
}
