package exam_q2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTickets implements iMovieTickets {

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        // Calculate price with VAT
        double totalPrice = numberOfTickets * ticketPrice;
        double vatAmount = totalPrice * 0.14;
        return totalPrice + vatAmount;
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        // Check validity of input data
        return movieTicketData.getMovieName() != null && !movieTicketData.getMovieName().isEmpty()
                && movieTicketData.getTicketPrice() > 0
                && movieTicketData.getTicketCount() > 0;
    }

    public void saveReportToFile(String movieName, double ticketPrice, int numberOfTickets, double totalTicketPrice) {
        // Saves formatted report to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write("MOVIE TICKET REPORT");
            writer.newLine();
            writer.write("**********************************************************");
            writer.newLine();
            writer.write("MOVIE NAME: " + movieName);
            writer.newLine();
            writer.write("MOVIE TICKET PRICE: " + ticketPrice);
            writer.newLine();
            writer.write("NUMBER OF TICKETS: " + numberOfTickets);
            writer.newLine();
            writer.write("TOTAL TICKET PRICE: " + totalTicketPrice);
            writer.newLine();
            writer.write("*************************************************************");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
