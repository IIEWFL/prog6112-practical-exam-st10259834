package exam_q2;

public class MovieTicketData {
    private String movieName;
    private int ticketCount;
    private double ticketPrice;

    public MovieTicketData(String movieName, int ticketCount, double ticketPrice) {
        this.movieName = movieName;
        this.ticketCount = ticketCount;
        this.ticketPrice = ticketPrice;
    }

    // Getters for data fields
    public String getMovieName() {
        return movieName;
    }

    public int getTicketCount() {
        return ticketCount;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }
}
