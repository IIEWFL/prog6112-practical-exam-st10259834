package exam_q2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class exam_q2 extends JFrame {

    private JComboBox<String> movieComboBox;
    private JTextField ticketCountField, ticketPriceField;
    private JTextArea reportArea;
    private MovieTickets movieTickets;

    public exam_q2() {
        // Frame settings and layout
        setTitle("Movie Tickets");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);  // Custom window decorations
        
        // Custom title bar with buttons
        JPanel titleBar = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Movie Tickets", JLabel.CENTER);
        JPanel titleButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton minimizeButton = new JButton("_");
        JButton fullscreenButton = new JButton("[ ]");
        JButton exitButton = new JButton("X");
        
        titleButtons.add(minimizeButton);
        titleButtons.add(fullscreenButton);
        titleButtons.add(exitButton);
        
        titleBar.add(titleLabel, BorderLayout.CENTER);
        titleBar.add(titleButtons, BorderLayout.EAST);
        
        // Exit button closes the app
        exitButton.addActionListener(e -> System.exit(0));
        
        // Panel for form inputs
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        
        // Combo box for movie selection
        JLabel movieLabel = new JLabel("Movie:");
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        
        // Number of tickets input
        JLabel countLabel = new JLabel("Number of Tickets:");
        ticketCountField = new JTextField(10);
        
        // Ticket price input
        JLabel priceLabel = new JLabel("Ticket Price:");
        ticketPriceField = new JTextField(10);
        
        // Read-only report area
        JLabel reportLabel = new JLabel("Ticket Report:");
        reportArea = new JTextArea(8, 30);
        reportArea.setEditable(false);
        
        // Add components to input panel
        inputPanel.add(movieLabel);
        inputPanel.add(movieComboBox);
        inputPanel.add(countLabel);
        inputPanel.add(ticketCountField);
        inputPanel.add(priceLabel);
        inputPanel.add(ticketPriceField);
        inputPanel.add(reportLabel);
        inputPanel.add(new JScrollPane(reportArea));
        
        // Menu bar setup
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(e -> processTicketSales());
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(e -> clearFields());
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        
        // Add title bar and input panel to frame
        setJMenuBar(menuBar);
        add(titleBar, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.CENTER);
        
        setVisible(true);
    }

    private void processTicketSales() {
        try {
            // Read user inputs
            String movie = (String) movieComboBox.getSelectedItem();
            int ticketCount = Integer.parseInt(ticketCountField.getText());
            double ticketPrice = Double.parseDouble(ticketPriceField.getText());
            
            MovieTicketData data = new MovieTicketData(movie, ticketCount, ticketPrice);
            movieTickets = new MovieTickets();

            // Validate and calculate ticket sales
            if (movieTickets.ValidateData(data)) {
                double totalPrice = movieTickets.CalculateTotalTicketPrice(ticketCount, ticketPrice);
                reportArea.setText("MOVIE NAME " + movie + "\n" +
                                   "MOVIE TICKET PRICE " + ticketPrice + "\n" +
                                   "NUMBER OF TICKETS: " + ticketCount + "\n" +
                                   "TOTAL TICKET PRICE: " + totalPrice);
                saveToFile(movie, ticketCount, ticketPrice, totalPrice);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid data. Please check input fields.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for ticket count and price.");
        }
    }

    private void saveToFile(String movie, int ticketCount, double ticketPrice, double totalPrice) {
        // Saves the report to a text file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write("MOVIE NAME: " + movie + "\n");
            writer.write("MOVIE TICKET PRICE: " + ticketPrice + "\n");
            writer.write("NUMBER OF TICKETS: " + ticketCount + "\n");
            writer.write("TOTAL TICKET PRICE: " + totalPrice + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        // Clears form fields
        ticketCountField.setText("");
        ticketPriceField.setText("");
        reportArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new exam_q2());
    }
}
