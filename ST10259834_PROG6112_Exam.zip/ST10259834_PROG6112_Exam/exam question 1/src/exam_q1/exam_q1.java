package exam_q1;

public class exam_q1 {
    public static void main(String[] args) {
        // Movie names and ticket sales data per month
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] ticketSalesData = {
            {3000, 1500, 1700},  // Monthly sales for Napoleon
            {3500, 1200, 1600}   // Monthly sales for Oppenheimer
        };

        // Array to store MovieTickets objects and total sales for each movie
        MovieTickets[] movieTicketsArray = new MovieTickets[movies.length];
        int[] totalSales = new int[movies.length];

        // Create MovieTickets objects and calculate total sales for each movie
        for (int i = 0; i < movies.length; i++) {
            movieTicketsArray[i] = new MovieTickets(movies[i], ticketSalesData[i]);
            totalSales[i] = movieTicketsArray[i].TotalMovieSales(ticketSalesData[i]);
        }

        // Display the sales report
        System.out.println("Movie Ticket Sales Report - 2024\n");
        System.out.println("               Jan        Feb         Mar");
        System.out.println("--------------------------------------------------------");
        System.out.printf("%-15s %4d        %4d        %4d\n", movies[0], ticketSalesData[0][0], ticketSalesData[0][1], ticketSalesData[0][2]);
        System.out.printf("%-15s %4d        %4d        %4d\n", movies[1], ticketSalesData[1][0], ticketSalesData[1][1], ticketSalesData[1][2]);

        System.out.println();

        // Display total ticket sales per movie
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("Total movie ticket sales for %s: %d\n", movies[i], totalSales[i]);
        }

        // Find and display the top-performing movie
        MovieTickets movieTicketInstance = new MovieTickets("", new int[0]);
        String topMovie = movieTicketInstance.TopMovie(movies, totalSales);
        System.out.println("\nTop performing movie: " + topMovie);
    }
}
