package exam_q1;

// Interface defining required methods for movie ticket calculations
public interface iMovieTickets {
    int TotalMovieSales(int[] movieTicketSales); // Calculate total sales
    String TopMovie(String[] movies, int[] totalSales); // Find top-performing movie
}
