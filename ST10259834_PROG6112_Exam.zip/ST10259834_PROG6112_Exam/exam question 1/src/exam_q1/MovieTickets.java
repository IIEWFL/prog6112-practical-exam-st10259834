package exam_q1;

public class MovieTickets implements iMovieTickets {
    private String movieName;  // Stores the name of the movie
    private int[] ticketSales; // Monthly ticket sales data

    // Constructor to initialize movie name and sales data
    public MovieTickets(String movieName, int[] ticketSales) {
        this.movieName = movieName;
        this.ticketSales = ticketSales;
    }

    // Method to retrieve movie name
    public String getMovieName() {
        return movieName;
    }

    // Calculates total ticket sales for a movie
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales; // Sum up monthly sales
        }
        return total;
    }

    // Identifies the movie with the highest sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        String topMovie = movies[0];
        
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }
        return topMovie;
    }
}
