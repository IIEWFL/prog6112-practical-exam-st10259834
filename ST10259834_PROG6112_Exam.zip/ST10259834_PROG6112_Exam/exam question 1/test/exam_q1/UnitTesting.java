/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package exam_q1;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MovieTickets class methods
 */
public class UnitTesting {

    public UnitTesting() {
    }

    // Test for calculating total sales
    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        int[] napoleonSales = {3000, 1500, 1700};
        MovieTickets napoleon = new MovieTickets("Napoleon", napoleonSales);

        int totalSales = napoleon.TotalMovieSales(napoleonSales);

        assertEquals(6200, totalSales, "The total sales for Napoleon should be 6200");
    }

    // Test for identifying the top-performing movie
    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};
        MovieTickets movieTickets = new MovieTickets("", new int[0]); // Placeholder instance

        String topMovie = movieTickets.TopMovie(movies, totalSales);

        assertEquals("Oppenheimer", topMovie, "The top-performing movie should be Oppenheimer");
    }
}
